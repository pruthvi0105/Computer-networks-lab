# creating 2 namespaces named red and blue
sudo ip netns add blue 
sudo ip netns add red
#creating the veth pair and assigning interfaces to network namespaces
sudo ip link add veth0 type veth peer name veth1
sudo ip link set veth0 netns red
sudo ip link set veth1 netns blue
# configure the veth1 interface in the blue namespace
sudo ip netns exec blue ip addr add 10.1.2.0/24 dev veth1
sudo ip netns exec blue ip link set dev veth1 up
# configure the veth0 interface in the red namespace
sudo ip netns exec red ip addr add 10.1.1.0/24 dev veth0
sudo ip netns exec red ip link set dev veth0 up
#for pinging
sudo ip -n red route add 10.1.2.0/24 dev veth0
sudo ip -n blue route add 10.1.1.0/24 dev veth1

