sudo ip netns add H1
sudo ip netns add H2
sudo ip netns add H3 #creating 3 namespaces
sudo ip netns add R

sudo ip netns exec R ip link add name brig type bridge

sudo ip link add veth1 type veth peer name veth2
sudo ip link add veth6 type veth peer name veth3
sudo ip link add veth5 type veth peer name veth4
#assign interface to namespaces
sudo ip link set veth1 netns H1
sudo ip link set veth6 netns H2
sudo ip link set veth5 netns H3

sudo ip link set veth2 netns R
sudo ip link set veth3 netns R
sudo ip link set veth4 netns R

sudo ip -n R link set brig up

#adding interfaces to the bridge
sudo ip netns exec R ip link set veth2 master brig
sudo ip netns exec R ip link set veth3 master brig
sudo ip netns exec R ip link set veth4 master brig

sudo ip -n H1 addr add 10.0.10.24/24 dev veth1
sudo ip -n H1 link set dev veth1 up
sudo ip -n H2 addr add 10.0.20.24/24 dev veth6
sudo ip -n H2 link set dev veth6 up
sudo ip -n H3 addr add 10.0.30.24/24 dev veth5
sudo ip -n H3 link set dev veth5 up

sudo sysctl -w net.ipv4.ip_forward=1

sudo ip -n R addr add 10.0.10.1/24 dev veth2
sudo ip -n R link set veth2 up
sudo ip -n R addr add 10.0.20.1/24 dev veth3
sudo ip -n R link set veth3 up
sudo ip -n R addr add 10.0.30.1/24 dev veth4
sudo ip -n R link set veth4 up

sudo ip -n H1 route add default via 10.0.10.24
sudo ip -n H2 route add default via 10.0.20.24
sudo ip -n H3 route add default via 10.0.30.24


