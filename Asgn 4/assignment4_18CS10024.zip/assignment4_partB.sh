sudo sysctl -w net.ipv4.ip_forward=1

#creating namespace
sudo ip netns add H1
sudo ip netns add H2
sudo ip netns add H3
sudo ip netns add H4

sudo ip netns add R1
sudo ip netns add R2
sudo ip netns add R3

sudo ip link add v1 type veth peer name v2
sudo ip link add v3 type veth peer name v4
sudo ip link add v5 type veth peer name v6
sudo ip link add v7 type veth peer name v8
sudo ip link add v9 type veth peer name v10
sudo ip link add v11 type veth peer name v12

#assign interface to namespaces
sudo ip link set v1 netns H1
sudo ip link set v2 netns R1
sudo ip link set v3 netns H2
sudo ip link set v4 netns R1
sudo ip link set v5 netns R1
sudo ip link set v6 netns R2
sudo ip link set v7 netns R2
sudo ip link set v8 netns R3
sudo ip link set v9 netns R3
sudo ip link set v10 netns H3
sudo ip link set v11 netns R3
sudo ip link set v12 netns H4

sudo ip -n H1 addr add 10.0.10.24/24 dev v1
sudo ip -n H1 link set dev v1 up
sudo ip -n R1 addr add 10.0.10.25/24 dev v2
sudo ip -n R1 link set dev v2 up
sudo ip -n H2 addr add 10.0.20.24/24 dev v3
sudo ip -n H2 link set dev v3 up
sudo ip -n R1 addr add 10.0.20.25/24 dev v4
sudo ip -n R1 link set dev v4 up
sudo ip -n R1 addr add 10.0.30.24/24 dev v5
sudo ip -n R1 link set dev v5 up
sudo ip -n R2 addr add 10.0.30.25/24 dev v6
sudo ip -n R2 link set dev v6 up
sudo ip -n R2 addr add 10.0.40.24/24 dev v7
sudo ip -n R2 link set dev v7 up
sudo ip -n R3 addr add 10.0.40.25/24 dev v8
sudo ip -n R3 link set dev v8 up
sudo ip -n R3 addr add 10.0.50.24/24 dev v9
sudo ip -n R3 link set dev v9 up
sudo ip -n H3 addr add 10.0.50.25/24 dev v10
sudo ip -n H3 link set dev v10 up
sudo ip -n R3 addr add 10.0.60.24/24 dev v11
sudo ip -n R3 link set dev v11 up
sudo ip -n H4 addr add 10.0.60.25/24 dev v12
sudo ip -n H4 link set dev v12 up

sudo ip netns exec H1 ip link set dev lo up
sudo ip netns exec H2 ip link set dev lo up
sudo ip netns exec H3 ip link set dev lo up
sudo ip netns exec H4 ip link set dev lo up
sudo ip netns exec R1 ip link set dev lo up
sudo ip netns exec R2 ip link set dev lo up
sudo ip netns exec R3 ip link set dev lo up

# H1 to 5 pairs via v2 
sudo ip netns exec H1 ip route add 10.0.20.0/24 via 10.0.10.25 dev v1
sudo ip netns exec H1 ip route add 10.0.30.0/24 via 10.0.10.25 dev v1
sudo ip netns exec H1 ip route add 10.0.40.0/24 via 10.0.10.25 dev v1
sudo ip netns exec H1 ip route add 10.0.50.0/24 via 10.0.10.25 dev v1
sudo ip netns exec H1 ip route add 10.0.60.0/24 via 10.0.10.25 dev v1

# H2 to 5 pairs via v4
sudo ip netns exec H2 ip route add 10.0.10.0/24 via 10.0.20.25 dev v3
sudo ip netns exec H2 ip route add 10.0.30.0/24 via 10.0.20.25 dev v3
sudo ip netns exec H2 ip route add 10.0.40.0/24 via 10.0.20.25 dev v3
sudo ip netns exec H2 ip route add 10.0.50.0/24 via 10.0.20.25 dev v3
sudo ip netns exec H2 ip route add 10.0.60.0/24 via 10.0.20.25 dev v3

# H3 to 5 pairs via v9
sudo ip netns exec H3 ip route add 10.0.10.0/24 via 10.0.50.24 dev v10
sudo ip netns exec H3 ip route add 10.0.20.0/24 via 10.0.50.24 dev v10
sudo ip netns exec H3 ip route add 10.0.30.0/24 via 10.0.50.24 dev v10
sudo ip netns exec H3 ip route add 10.0.40.0/24 via 10.0.50.24 dev v10
sudo ip netns exec H3 ip route add 10.0.60.0/24 via 10.0.50.24 dev v10

# H4 to 5 pairs via v11
sudo ip netns exec H4 ip route add 10.0.10.0/24 via 10.0.60.24 dev v12
sudo ip netns exec H4 ip route add 10.0.20.0/24 via 10.0.60.24 dev v12
sudo ip netns exec H4 ip route add 10.0.30.0/24 via 10.0.60.24 dev v12
sudo ip netns exec H4 ip route add 10.0.40.0/24 via 10.0.60.24 dev v12
sudo ip netns exec H4 ip route add 10.0.50.0/24 via 10.0.60.24 dev v12

# R1 to 3 pairs via v6
sudo ip netns exec R1 ip route add 10.0.40.0/24 via 10.0.30.25 dev v5
sudo ip netns exec R1 ip route add 10.0.50.0/24 via 10.0.30.25 dev v5
sudo ip netns exec R1 ip route add 10.0.60.0/24 via 10.0.30.25 dev v5

# R3  to 3 pairs via v7
sudo ip netns exec R3 ip route add 10.0.10.0/24 via 10.0.40.24 dev v8
sudo ip netns exec R3 ip route add 10.0.20.0/24 via 10.0.40.24 dev v8
sudo ip netns exec R3 ip route add 10.0.30.0/24 via 10.0.40.24 dev v8

# R2  to 2 pairs via v5 
sudo ip netns exec R2 ip route add 10.0.10.0/24 via 10.0.30.24 dev v6
sudo ip netns exec R2 ip route add 10.0.20.0/24 via 10.0.30.24 dev v6

# R2 -to 2 pairs via v8
sudo ip netns exec R2 ip route add 10.0.50.0/24 via 10.0.40.25 dev v7
sudo ip netns exec R2 ip route add 10.0.60.0/24 via 10.0.40.25 dev v7


sudo ip netns exec H1 ping -c3 10.0.10.24
sudo ip netns exec H1 ping -c3 10.0.10.25
sudo ip netns exec H1 ping -c3 10.0.20.24
sudo ip netns exec H1 ping -c3 10.0.20.25
sudo ip netns exec H1 ping -c3 10.0.30.24
sudo ip netns exec H1 ping -c3 10.0.30.25
sudo ip netns exec H1 ping -c3 10.0.40.24
sudo ip netns exec H1 ping -c3 10.0.40.25
sudo ip netns exec H1 ping -c3 10.0.50.24
sudo ip netns exec H1 ping -c3 10.0.50.25
sudo ip netns exec H1 ping -c3 10.0.60.24
sudo ip netns exec H1 ping -c3 10.0.60.25

sudo ip netns exec H2 ping -c3 10.0.10.24
sudo ip netns exec H2 ping -c3 10.0.10.25
sudo ip netns exec H2 ping -c3 10.0.20.24
sudo ip netns exec H2 ping -c3 10.0.20.25
sudo ip netns exec H2 ping -c3 10.0.30.24
sudo ip netns exec H2 ping -c3 10.0.30.25
sudo ip netns exec H2 ping -c3 10.0.40.24
sudo ip netns exec H2 ping -c3 10.0.40.25
sudo ip netns exec H2 ping -c3 10.0.50.24
sudo ip netns exec H2 ping -c3 10.0.50.25
sudo ip netns exec H2 ping -c3 10.0.60.24
sudo ip netns exec H2 ping -c3 10.0.60.25

sudo ip netns exec H3 ping -c3 10.0.10.24
sudo ip netns exec H3 ping -c3 10.0.10.25
sudo ip netns exec H3 ping -c3 10.0.20.24
sudo ip netns exec H3 ping -c3 10.0.20.25
sudo ip netns exec H3 ping -c3 10.0.30.24
sudo ip netns exec H3 ping -c3 10.0.30.25
sudo ip netns exec H3 ping -c3 10.0.40.24
sudo ip netns exec H3 ping -c3 10.0.40.25
sudo ip netns exec H3 ping -c3 10.0.50.24
sudo ip netns exec H3 ping -c3 10.0.50.25
sudo ip netns exec H3 ping -c3 10.0.60.24
sudo ip netns exec H3 ping -c3 10.0.60.25

sudo ip netns exec H4 ping -c3 10.0.10.24
sudo ip netns exec H4 ping -c3 10.0.10.25
sudo ip netns exec H4 ping -c3 10.0.20.24
sudo ip netns exec H4 ping -c3 10.0.20.25
sudo ip netns exec H4 ping -c3 10.0.30.24
sudo ip netns exec H4 ping -c3 10.0.30.25
sudo ip netns exec H4 ping -c3 10.0.40.24
sudo ip netns exec H4 ping -c3 10.0.40.25
sudo ip netns exec H4 ping -c3 10.0.50.24
sudo ip netns exec H4 ping -c3 10.0.50.25
sudo ip netns exec H4 ping -c3 10.0.60.24
sudo ip netns exec H4 ping -c3 10.0.60.25

sudo ip netns exec R1 ping -c3 10.0.10.24
sudo ip netns exec R1 ping -c3 10.0.10.25
sudo ip netns exec R1 ping -c3 10.0.20.24
sudo ip netns exec R1 ping -c3 10.0.20.25
sudo ip netns exec R1 ping -c3 10.0.30.24
sudo ip netns exec R1 ping -c3 10.0.30.25
sudo ip netns exec R1 ping -c3 10.0.40.24
sudo ip netns exec R1 ping -c3 10.0.40.25
sudo ip netns exec R1 ping -c3 10.0.50.24
sudo ip netns exec R1 ping -c3 10.0.50.25
sudo ip netns exec R1 ping -c3 10.0.60.24
sudo ip netns exec R1 ping -c3 10.0.60.25

sudo ip netns exec R2 ping -c3 10.0.10.24
sudo ip netns exec R2 ping -c3 10.0.10.25
sudo ip netns exec R2 ping -c3 10.0.20.24
sudo ip netns exec R2 ping -c3 10.0.20.25
sudo ip netns exec R2 ping -c3 10.0.30.24
sudo ip netns exec R2 ping -c3 10.0.30.25
sudo ip netns exec R2 ping -c3 10.0.40.24
sudo ip netns exec R2 ping -c3 10.0.40.25
sudo ip netns exec R2 ping -c3 10.0.50.24
sudo ip netns exec R2 ping -c3 10.0.50.25
sudo ip netns exec R2 ping -c3 10.0.60.24
sudo ip netns exec R2 ping -c3 10.0.60.25

sudo ip netns exec R3 ping -c3 10.0.10.24
sudo ip netns exec R3 ping -c3 10.0.10.25
sudo ip netns exec R3 ping -c3 10.0.20.24
sudo ip netns exec R3 ping -c3 10.0.20.25
sudo ip netns exec R3 ping -c3 10.0.30.24
sudo ip netns exec R3 ping -c3 10.0.30.25
sudo ip netns exec R3 ping -c3 10.0.40.24
sudo ip netns exec R3 ping -c3 10.0.40.25
sudo ip netns exec R3 ping -c3 10.0.50.24
sudo ip netns exec R3 ping -c3 10.0.50.25
sudo ip netns exec R3 ping -c3 10.0.60.24
sudo ip netns exec R3 ping -c3 10.0.60.25

#traceroute to show hops from H1 to H4
sudo ip netns exec H1 traceroute 10.0.60.25
sleep 2

#traceroute to show hops from H3 to H4
sudo ip netns exec H3 traceroute 10.0.60.25
sleep 2

#traceroute to show hops from H4 to H2
sudo ip netns exec H4 traceroute 10.0.20.24