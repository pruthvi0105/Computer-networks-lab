sudo sysctl -w net.ipv4.ip_forward=1
sudo ip netns add N1
sudo ip netns add N2
sudo ip netns add N3
sudo ip netns add N4


sudo ip link add V1 type veth peer name V2
sudo ip link add V3 type veth peer name V4
sudo ip link add V5 type veth peer name V6


sudo ip link set V1 netns N1
sudo ip link set V2 netns N2
sudo ip link set V3 netns N2
sudo ip link set V4 netns N3
sudo ip link set V5 netns N3
sudo ip link set V6 netns N4

sudo ip -n N1 addr add 10.0.10.24/24 dev V1
sudo ip -n N1 link set dev V1 up

sudo ip -n N2 addr add 10.0.10.25/24 dev V2
sudo ip -n N2 link set dev V2 up

sudo ip -n N2 addr add 10.0.20.24/24 dev V3
sudo ip -n N2 link set dev V3 up

sudo ip -n N3 addr add 10.0.20.25/24 dev V4
sudo ip -n N3 link set dev V4 up

sudo ip -n N3 addr add 10.0.30.24/24 dev V5
sudo ip -n N3 link set dev V5 up

sudo ip -n N4 addr add 10.0.30.25/24 dev V6
sudo ip -n N4 link set dev V6 up

sudo ip netns exec N1 ip link set dev lo up
sudo ip netns exec N2 ip link set dev lo up
sudo ip netns exec N3 ip link set dev lo up
sudo ip netns exec N4 ip link set dev lo up

sudo ip netns exec N1 ip route add 10.0.20.0/24 via 10.0.10.25 dev V1
sudo ip netns exec N1 ip route add 10.0.30.0/24 via 10.0.10.25 dev V1
sudo ip netns exec N2 ip route add 10.0.30.0/24 via 10.0.20.25 dev V3
sudo ip netns exec N3 ip route add 10.0.10.0/24 via 10.0.20.24 dev V4
sudo ip netns exec N4 ip route add 10.0.10.0/24 via 10.0.30.24 dev V6
sudo ip netns exec N4 ip route add 10.0.20.0/24 via 10.0.30.24 dev V6


sudo ip netns exec N1 ping -c3 10.0.10.24
sudo ip netns exec N1 ping -c3 10.0.10.25
sudo ip netns exec N1 ping -c3 10.0.20.24
sudo ip netns exec N1 ping -c3 10.0.20.25
sudo ip netns exec N1 ping -c3 10.0.30.24
sudo ip netns exec N1 ping -c3 10.0.30.25

sudo ip netns exec N2 ping -c3 10.0.10.24
sudo ip netns exec N2 ping -c3 10.0.10.25
sudo ip netns exec N2 ping -c3 10.0.20.24
sudo ip netns exec N2 ping -c3 10.0.20.25
sudo ip netns exec N2 ping -c3 10.0.30.24
sudo ip netns exec N2 ping -c3 10.0.30.25

sudo ip netns exec N3 ping -c3 10.0.10.24
sudo ip netns exec N3 ping -c3 10.0.10.25
sudo ip netns exec N3 ping -c3 10.0.20.24
sudo ip netns exec N3 ping -c3 10.0.20.25
sudo ip netns exec N3 ping -c3 10.0.30.24
sudo ip netns exec N3 ping -c3 10.0.30.25

sudo ip netns exec N4 ping -c3 10.0.10.24
sudo ip netns exec N4 ping -c3 10.0.10.25
sudo ip netns exec N4 ping -c3 10.0.20.24
sudo ip netns exec N4 ping -c3 10.0.20.25
sudo ip netns exec N4 ping -c3 10.0.30.24
sudo ip netns exec N4 ping -c3 10.0.30.25





